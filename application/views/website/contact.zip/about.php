<!doctype html>
<!--    style="line-height:2;"     --> 
<html lang="en,hi">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content>
    <meta name="author" content="DynamicLayers">
    <title>Ngo/Charity|| Farmer becomes businessman</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

        <style type="text/css">
        @font-face {
            font-family: kruti dev;
            src: url("fonts/Kruti_Dev_010.ttf"), url("fonts/Kruti_Dev_010.eot");
        }
    </style>
    <?php include('include/css.php'); ?>
</head>

<body>

    <?php include('include/header.php'); ?>

    <div class="header-height"></div>


    <section class="slider-section">
        <div class="slider-wrapper">

            <div id="main-slider" class="nivoSlider" style="height:300px;">

                <img src="themes/img/about-image-1.jpg" alt title="#slider-caption-1" />
              
            </div>

            <div id="slider-caption-1" class="nivo-html-caption slider-caption">
            <!-- <p class="wow cssanimation leFadeInRight sequence" style="margin-top:60px;margin-left: 138px; font-size55px;" >About Us</p> -->

                <div class="display-table">
                    <div class="table-cell">
                        <div class="container">
                            <div class="slider-text">
                                <h5 class="wow cssanimation fadeInBottom">Join Us Today</h5>
                                <h1 class="wow cssanimation leFadeInRight sequence">About Us</h1>
                                <p class="wow cssanimation fadeInTop" data-wow-delay="1s" style="line-height:2; color:white;">Help
                                    today because
                                    tomorrow you may be the one who needs helping! <br>Forget what you can get and see
                                    what you can give.
                                </p>
                                <a href="index.php" class="default-btn wow cssanimation fadeInBottom" data-wow-delay="0.8s">Home</a>
                                <a href="javaScript:void(0);" class="default-btn wow cssanimation fadeInBottom"
                                    data-wow-delay="0.8s">About Us</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="slider-caption-2" class="nivo-html-caption slider-caption">
                <div class="display-table">
                    <div class="table-cell">
                        <div class="container">
                            <div class="slider-text">
                                <h1 class="wow cssanimation fadeInTop" data-wow-delay="1s" data-wow-duration="800ms">
                                    Farmer becomes
                                    bussinessman</h1>
                                <p class="wow cssanimation fadeInBottom" data-wow-delay="1s" style="line-height:2;">Help
                                    today because
                                    tomorrow you may be the one who needs helping! <br>Forget what you can get and see
                                    what you can give.
                                </p>
                                <a href="#" class="default-btn wow cssanimation fadeInBottom" data-wow-delay="0.8s">Join
                                    With Us</a>
                                <a href="#" class="default-btn wow cssanimation fadeInBottom"
                                    data-wow-delay="0.8s">Donet Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="slider-caption-3" class="nivo-html-caption slider-caption">
                <div class="display-table">
                    <div class="table-cell">
                        <div class="container">
                            <div class="slider-text">
                                <h5 class="wow cssanimation fadeInBottom">Join Us Today</h5>
                                <h1 class="wow cssanimation lePushReleaseFrom sequence" data-wow-delay="1s"
                                    style="line-height:2;">
                                    Farmer becomes bussinessman</h1>
                                <p class="wow cssanimation fadeInTop" data-wow-delay="1s">Help today because tomorrow
                                    you may be the one
                                    who needs helping! <br>Forget what you can get and see what you can give.</p>
                                <a href="#" class="default-btn wow cssanimation fadeInBottom" data-wow-delay="0.8s">Join
                                    With Us</a>
                                <a href="#" class="default-btn wow cssanimation fadeInBottom"
                                    data-wow-delay="0.8s">Donet Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <div class="container" style="margin-top:100px; box-shadow: 20px 20px 50px 10px green inset; padding-top:55px;">


        <div class="row" style="border-radius: 10px;margin: 10px 0px;padding: 30px 30px 10px 30px ;">
            <div class="col-12 col-sm-12 col-md-12 col-lg-6">
                <h3>VISION of KBCCI</h3>
                <p style="text-align:justify;font-size: 16px;  line-height: 1.5 !important;">Transforming Kisan
                    Kommunity into Entrepreneurs/Industrialist and make a network of one lakh entrepreneurs within five
                    years. (KISAN BANEGA UDHOGPATI)</p>

            </div>
            <div class="col-12 col-sm-12 col-md-12 col-lg-6">
                <h3>दृष्टिकोण</h3>
                <p style="text-align:justify; font-size: 15px;  line-height: 1.8 !important;">कृषक समाज को व्यवसायी /
                    उद्योगपति बनाना और पाँच वर्ष के भीतर 01 लाख व्यवसायियों का नेटवर्क बनाना ।</p>

            </div>
        </div>


        <div class="row" style="border-radius: 10px;margin: 10px 0px;padding: 0px 30px 0px 30px">
            <div class="col-12 col-sm-12 col-md-12 col-lg-6">
                <h3>MISSION of KBCCI</h3>
                <p style="text-align:justify;font-size: 16px;line-height: 1.5 !important;">To translate the Kommunity’s
                    “social capital into financial capital” through developing entrepreneurship among existing, rising
                    and potential entrepreneurs to mitigate their socio-economic problems that leads us to contribute in
                    creating wealth and catalyze the inclusive growth of nation</p>

            </div>
            <div class="col-12 col-sm-12 col-md-12 col-lg-6">
                <h3>ध्येय</h3>
                <p style="text-align:justify; font-size: 15px;line-height: 1.8 !important;">कृषि समाज के वर्तमान, उभरते
                    हुये और क्षमतावान प्रतिभाओं में व्यावसायिक / व्यापारिक गुण का विकास करके “सामाजिक पूँजी को वित्तीय
                    पूँजी“ में बदलना जो आगे चल कर हमें देश के विकास और समृद्धि में अंशदाता बनायें ।</p>

            </div>
        </div>


        <div class="row" style="border-radius: 10px;margin: 10px 0px;padding: 10px 30px 0px 30px">
            <div class="col-12 col-sm-12 col-md-12 col-lg-6">
                <h3>VALUE PROPOSITION OF KBCCI</h3>
                <p style="text-align:justify;font-size: 16px;line-height: 1.5 !important;">KBCCI is a non profit
                    organization transforming kisan kommunity into Industrialist/Entrepreneurs through developing
                    entrepreneurship among existing/rising/potential entrepreneurs, professionals, consultants, educated
                    youths and farmers of kisan kommunity. Apart from other existing chamber of commerce and Industry in
                    India, KBCCI is exclusively empowering kisan kommunity financially through entrepreneurship to tap
                    the benefits of liberal market economy to mitigate their socio-economic problem and enable them to
                    contribute in creating wealth for nation and inducing inclusive growth to bridge urban-rural divide.
                </p>

            </div>
            <div class="col-12 col-sm-12 col-md-12 col-lg-6">
                <h3>मूल्यात्मक मानदंड</h3>
                <p style="text-align:justify; font-size: 15px;line-height: 1.8 !important;">केबीसीसीआई एक गैर लाभकारी संस्था
                    है जो किसान समाज के वर्तमान, उभरते हुये, क्षमतावान किन्तु अविकसित प्रतिभाओं, पेशेवर सलाहकार नौजवानो
                    में उद्यमशीलता का विकास कर के उन्हें उद्योगपति बनायेगी। अन्य बहुत से आर्थिक संगठनों से अलग केबीसीसीआई
                    बाजारोन्मुखी अवसरों को कृषक समाज तक पहुँचा कर तथा उनमें उद्यमशीलता पैदा कर के उन्हें सक्षम बनायेगी ।
                    जिससे शहर और गॉंव की खाई कम हो और देश के आर्थिक विकास में उनका उल्लेखनीय योगदान हो ।</p>

            </div>
        </div>


        <div class="row" style="border-radius: 10px;margin: 10px 0px;padding:10px 30px 0px 30px;">
            <div class="col-12 col-sm-12 col-md-12 col-lg-6">
                <h3>BACKGROUND AND RATIONALE OF KBCCI</h3>
                <p style="text-align:justify;font-size: 16px;line-height: 1.5 !important;">We, the kisan clan (an
                    agrarian kommunity), are the leader of agriculture and related activities. Since centuries we have
                    been making substantial contribution in country’s GDP via agriculture. India adopted liberal
                    economic policy in the year 1991. It opened the flood gates of liberal economic market to all
                    sections of society. Urban society harnessed this opportunity but rural kisan kommunity is still
                    facing obstacles and the rural-urban divide has grossly increased since then. So the need of hour is
                    to shift agrarian kommunity from semi-feudal rural economy to urban economy and motivate them to
                    join modern occupations and agro-business.
                    The kommunity has been a major social capital in our growth process. Enormous economic benefits flow
                    through social capital. The kommunity has immense capability to consolidate business and
                    entrepreneurship. It also inherent social capital in form of high level of trust amongst its members
                    which greatly reduces risk and cost of business. Hence its high time that we transform this social
                    capital into financial capital.
                    In the back drop of above mentioned scenario, it has motivated us to constitute a body which will
                    have potential to translate our kommunity’s social capital into financial capital. In the result of
                    this thought process and with inspiration and mentorship of JANADHAR SANGATHAN (JS: working for
                    kommunity’s social capitalization-Lucknow, U.P.) an unique chamber of commerce and industry for our
                    kommunity came into reality on 26th August, 2016 in the name of – KOMMUNITY INDIAN CHAMBER OF
                    COMMERCE & INDUSTRY (KBCCI).
                    The target group of KBCCI are kommunity’s farmers, existing entrepreneurs, rising entrepreneurs,
                    potential entrepreneurs, professionals/ consultants, unemployed educated youths.</p>

            </div>
            <div class="col-12 col-sm-12 col-md-12 col-lg-6">
                <h3>केबीसीसीआई की अवधारणा एवं पृष्ठभूमि</h3>
                <p style="text-align:justify; font-size: 15px;line-height: 1.8 !important;">हम 'कृषक समाज' मुख्यतः कृषि
                    एवं सहायक क्रियाकलापों में अग्रणी है। सदियों से हम देश के सकल घरेलू उत्पाद विकास में कृषि के द्धारा
                    उल्लेखनीय योगदान करते आ रहे हैं । भारत ने वर्ष 1991 में उदार आर्थिक नीति अपनाई। इसने उदार आर्थिक
                    बाजार के द्धार समाज के सभी वर्गों के लिए स्वतंत्र रूप से खोल दिए। शहरी समाज ने इस अवसर का जम के लाभ
                    उठाया । जबकि गॉंव के किसान समाज के लिए गतिरोध आज भी दूर नहीं हुये हैं । परिणामस्वरूप शहर - गॉंव के
                    बीच खाई और बढ़ गयी है । अतः यह समय की मांग है कि कृषक समाज को छदम बेरोजगारी से बाहर लाकर शहरी
                    अर्थव्यवस्था से जुड़ने के लिए प्रोत्साहित किया जाये ।

                    कृषक समाज के पास हमारी प्रक्रिया के लिए बहुत बड़ी सामाजिक पूँजी है जिसके अनगिनत लाभ मिल सकते हैं ।
                    समाज में व्यापार एवं उद्यमिता के लिए अपार क्षमता समाहित है। कृषक समाज की आंतरिक शक्ति उनके सदस्यों
                    का आपसी जुड़ाव एवं विश्वास है जो अंततः व्यापार के जोखिम एवं व्यय को कम करता है । इसलिए यह समय की माँग
                    है कि हम इस सामाजिक पूँजी को वित्तीय पूँजी में बदल डालें ।

                    इन सब स्तिथियों के परिदृश्य में यह प्रेरणा जगी कि एक ऐसी संस्था का गठन किया जाये जो हमारे किसान समाज
                    की 'सामाजिक पूँजी' को 'वित्तीय पूँजी' में बदल सके। जनाधार संगठन (समाज की क्षमताओं के विकास एवं
                    संगठित करने हेतु कार्यरत संगठन) की प्रेरणा एवं अनगिनत बैठकों में संपन्न विचार विनिमय की प्रक्रिया के
                    बाद दिंनाक 26 अगस्त 2016 को हमारे कृषक समाज के 'चैम्बर ऑफ़ कॉमर्स एंड इंडस्ट्री' का गठन किया गया
                    जिसका नाम "कम्युनिटी इंडियन चैम्बर ऑफ़ कॉमर्स एंड इंडस्ट्री" रखा गया।

                    केबीसीसीआई का लक्ष्य समूह: समाज के किसान, कार्यरत उद्यमी, उदीयमान उद्यमी, अविकसित क्षमतावान उद्यमी,
                    पेशेवर / सलाहकार, बेरोजगार युवा आदि केबीसीसीआई के लक्ष्य समूह में शामिल है।</p>

            </div>
        </div>


        <div class="row" style="border-radius: 10px;margin: 10px 0px;padding: 30px;">
            <div class="col-12 col-sm-12 col-md-12 col-lg-6">
                <h3>FOUNDATION HISTORY OF KBCCI</h3>
                <p style="text-align:justify;font-size: 16px;line-height: 1.5 !important;">The idea of a chamber of
                    commerce and Industry for farmer Kommunity was floated in Janadhar Sangthan workshop held on 10th
                    April, 2016 in IIM-Lucknow and brief presentation put in this workshop. On 25th May, 2016 around 50
                    industrialist and entrepreneurs of our Kommunity assembled in Noida and decided to frame small
                    working core group on –finance, management, legal, IT, event management etc. These core group worked
                    hard and finally KBCCI came in shape. KBCCI got registered under section-8 of Companies Act 2013 .
                    It got registered on 26th August 2016. Foundation ceremony was held in the club of sector 26 Noida (
                    U.P. ) on 28th August, 2016.</p>

            </div>
            <div class="col-12 col-sm-12 col-md-12 col-lg-6">
                <h3>केबीसीसीआई का आधार इतिहास</h3>
                <p style="text-align:justify; font-size: 15px;line-height: 1.8 !important;">दिनांक 10 अप्रैल 2016 को
                    आई.आई.ऍम. लखनऊ में सम्पन्न जनाधार संगठन की कार्यशाला में एक प्रस्तुतीकरण के द्धारा कृषक समाज के लिए
                    उद्योग एवं व्यापार मॉडल के गठन का विचार लाया गया । दिनांक 25 मई 2016 को हमारे कृषक समाज के लगभग 50
                    उद्योगपति एवं उद्यमी नोयडा में एकत्र हुए और वित्त, प्रबंधन, वैधानिक, सूचना - तकनीक, कार्य प्रबंधन
                    आदि के लिए कार्यदल के गठन का निर्णय लिया । इन कार्यदलों के अथक प्रयासों से केबीसीसीआई का वर्तमान स्वरुप
                    सामने आया । भारतीय कम्पनीज एक्ट 2013 की धारा 08 के तहत दिनांक 26 अगस्त 2016 को केबीसीसीआई का पंजीकरण हो
                    चुका है । केबीसीसीआई का स्थापना समारोह 28 अगस्त 2016 को नोयडा के सेक्टर 26 में स्थित क्लब में धूमधाम से
                    मनाया गया ।</p>

            </div>
        </div>



        <div class="row" style="border-radius: 10px;margin: 10px 0px;padding: 30px;">
            <div class="col-12 col-sm-12 col-md-12 col-lg-6">
                <h3>ACTIVITIES AND SERVICES OFFERED BY KBCCI</h3>
                <p class="about-text"><i class="fa fa-hand-o-right" aria-hidden="true"
                        style="text-align: justify;font-size: 14px;line-height: 1.8;"></i>  Implement Entrepreneur Development Program (EDP) and incubation to entrepreneurs.</p>
                <p class="about-text" style="text-align: justify;font-size: 16px;line-height: 1.4 !important; "><i
                        class="fa fa-hand-o-right" aria-hidden="true"></i> Networking and provide business services like: B2B (Business to Business), B2C (Business to Customer) and B2G (Business to Government). </p>
                <p class="about-text"><i class="fa fa-hand-o-right" aria-hidden="true"
                        style="text-align: justify;font-size: 14px;line-height: 1.8;"></i>&nbsp; Promote and facilitate Agri-Business and make access to farmers in supply chain and marketing. </p>
                <p class="about-text"><i class="fa fa-hand-o-right" aria-hidden="true"
                        style="text-align: justify;font-size: 14px;line-height: 1.8;"></i>&nbsp;Promote and create ecosystem for innovation, research and development and facilitate in commercialization of Technology. </p>
                
              <p class="about-text"><i class="fa fa-hand-o-right" aria-hidden="true"
                        style="text-align: justify;font-size: 14px;line-height: 1.8;"></i>&nbsp;Assist and suggest the government and corporate bodies in policy making and information dessimination. </p>  
            <p class="about-text"><i class="fa fa-hand-o-right" aria-hidden="true"
                        style="text-align: justify;font-size: 14px;line-height: 1.8;"></i>&nbsp; Take web initiatives, ICT (Information and Communication Technology), promote and facilitate to e-commerce and financial inclusion. </p>     
            <p class="about-text"><i class="fa fa-hand-o-right" aria-hidden="true"
                        style="text-align: justify;font-size: 14px;line-height: 1.8;"></i>&nbsp; Promote knowledge base economy. Provide consultancy services and arbitration.</p>     
         <p class="about-text"><i class="fa fa-hand-o-right" aria-hidden="true"
                        style="text-align: justify;font-size: 14px;line-height: 1.8;"></i>&nbsp; Coordination and lobbying with Government bodies of India and multi global organizations like-UNO, UNIDO, WTO, WORLD BANK, IMF BRICS, SAARC, FAO, EUROPEAN UNION, ASEAN etc.</p>   
          <p class="about-text"><i class="fa fa-hand-o-right" aria-hidden="true"
                        style="text-align: justify;font-size: 14px;line-height: 1.8;"></i>&nbsp; Launch and implement corporate social responsibility (CSR) though KBCCI.</p>    
        <p class="about-text"><i class="fa fa-hand-o-right" aria-hidden="true"
                        style="text-align: justify;font-size: 14px;line-height: 1.8;"></i>&nbsp;Promote Green initiatives in all product and services of KBCCI entrepreneurs to make world green and carbon neutral.</p>

                        


            </div>
            <div class="col-12 col-sm-12 col-md-12 col-lg-6">
                <h3>केबीसीसीआई के उद्देश्य</h3>
                <p lang="hi" class="hinditext text-justify about-texthn" style="text-align:justify; font-size: 15px;line-height: 1.8 !important;"><i class="fa fa-hand-o-right" aria-hidden="true"></i>  उद्यमी विकास कार्यक्रम को लागू करना एवं उद्यमियों का पोषण ।</p>

                <p lang="hi" class="hinditext text-justify about-texthn" style="text-align:justify; font-size: 15px;line-height: 1.8 !important;"><i class="fa fa-hand-o-right" aria-hidden="true"></i>  टवर्किंग एवं व्यावसायिक सेवायें जैसे B2B (Business to Business), B2C (Business to customer), B2G (Business to Government)</p>
                <p lang="hi" class="hinditext text-justify about-texthn"style="text-align:justify; font-size: 15px;line-height: 1.8 !important;"><i class="fa fa-hand-o-right" aria-hidden="true"></i>कृषि आधारित वयवसाय को बढ़ावा देना व् सुविधायें देना, और किसानो को विपरण एवं मार्केटिंग में जगह देना </p>
                <p lang="hi" class="hinditext text-justify about-texthn"style="text-align:justify; font-size: 15px;line-height: 1.8 !important;"><i class="fa fa-hand-o-right" aria-hidden="true"></i>सूचना विकास एवं नीति निर्धारण में सरकार एवं निकाय को सहायता एवं सुझाव देना ।</p>
                <p lang="hi" class="hinditext text-justify about-texthn"style="text-align:justify; font-size: 15px;line-height: 1.8 !important;"><i class="fa fa-hand-o-right" aria-hidden="true"></i> वेब आधारित क्रियाकलापों को बढ़ावा देना, सूचना एवं संवाद-तकनीकी और ई-कॉमर्स को प्रोत्साहन देना ।</p>
                <p lang="hi" class="hinditext text-justify about-texthn"style="text-align:justify; font-size: 15px;line-height: 1.8 !important;"><i class="fa fa-hand-o-right" aria-hidden="true"></i> ज्ञान आधारित अर्थव्यवस्था को प्रोत्साहन देना ।</p>
                <p lang="hi" class="hinditext text-justify about-texthn"style="text-align:justify; font-size: 15px;line-height: 1.8 !important;"><i class="fa fa-hand-o-right" aria-hidden="true"></i>सलाहकार सेवाएं देना तथा व्यावसायिक विवाद में मध्यस्तथा करना ।</p>
                <p lang="hi" class="hinditext text-justify about-texthn"style="text-align:justify; font-size: 15px;line-height: 1.8 !important;"><i class="fa fa-hand-o-right" aria-hidden="true"></i>  भारत सरकार, सरकारी विभागों, वैश्विक संगठनों से तालमेल जैसे UNO, UNIDO, WTO, World Bank, IMF, BRICKS, SAARC, FAO, European Union, ASEAN etc</p>
                <p lang="hi" class="hinditext text-justify about-texthn"style="text-align:justify; font-size: 15px;line-height: 1.8 !important;"><i class="fa fa-hand-o-right" aria-hidden="true"></i> कॉरपोरेट सामाजिक दायित्वों का केबीसीसीआई के माध्यम से लागूकरण ।</p>
                <p lang="hi" class="hinditext text-justify about-texthn"style="text-align:justify; font-size: 15px;line-height: 1.8 !important;"><i class="fa fa-hand-o-right" aria-hidden="true"></i>संसार को हरा भरा करने एवं कार्बन मुक्त करने के लिए केबीसीसीआई उद्यमियों की सभी सेवाओं और वस्तुओं में हरित आंदोलन को प्रोत्साहन ।</p>



            </div>
        </div>

        <div class="row" style="border-radius: 10px;margin: 10px 0px;padding: 10px 30px 0px 30px">
            <div class="col-12 col-sm-12 col-md-12 col-lg-6">
                <h3>ORGANIZATIONL SETUP OF KBCCI</h3>
                <p style="text-align:justify;font-size: 16px;line-height: 1.5 !important;">KBCCI is registered under section-8. of Companies Act 2013. Registration Number: CIN No. U74999DL2016NPL304990 dated: 26th August, 2016. It is a non profit organization having Eleven directors.
                </p>
                <p style="text-align:justify;font-size: 16px;line-height: 1.5 !important;"><strong>1. Share Holder/Life Time Member: </strong> Shares may be allotted to those who deposited Rs. 1,10,000/- subject to the approval of Board of Directors (BOD) and Directors will be elected among the share holders.
                </p>
                <p style="text-align:justify;font-size: 16px;line-height: 1.5 !important;"><strong>2. General Members:</strong> May be enrolled those who deposited Rs.10,000/- (Rs. 5,000/- membership fee and Rs. 5,000/- will be annual subscription). Subjected to the approval of Board of Directors (BOD).
                </p>
                <p style="text-align:justify;font-size: 16px;line-height: 1.5 !important;"><strong>3. Rising/Potential Entrepreneurs/Professionals:</strong> May be registered by paying one time Rs. 500/- subjected to the approval of Board of Directors (BOD).
                </p>
                <p style="text-align:justify;font-size: 16px;line-height: 1.5 !important;"><strong>Associate Membership:</strong> May be allotted to corporate groups with fee as decided by Board of Directors (BOD).
                </p>
                <p style="text-align:justify;font-size: 16px;line-height: 1.5 !important;"><strong>Financial Details:

</strong><br> All payment should be made in favor of “Kommunity Indian Chamber of Commerce and Industry” payable at Delhi in bank account number 36146721781. State Bank of India, Branch: Connaught Circus, New Delhi- 110001. IFSC: SBI0030203
                </p>

                

            </div>
            <div class="col-12 col-sm-12 col-md-12 col-lg-6">
                <h3>केबीसीसीआई का संगठनात्मक ढ़ाचा</h3>
                <p style="text-align:justify; font-size: 15px;line-height: 1.8 !important;">केबीसीसीआई का पंजीकरण कम्पनीज एक्ट 2013 की धारा 08 के तहत हुआ है । इसका पंजीकरण संख्या CIN No. U74999DL2016NPL304990 दिंनाक 26 अगस्त 2016 है । यह एक गैर लाभकारी संस्था हैं जिसमे 11 निर्देशक हैं ।</p>

                <p style="text-align:justify; font-size: 15px;line-height: 1.8 !important;"><strong>1- अंशधारक / आजीवन सदस्य : </strong>रुपये 1,10,000 /- जमा करने वाले को अंशधारक बनाया जा सकता है, बशर्ते कि निर्देशक मंडल उसका अनुमोदन करें । निर्देशक मंडल का चयन अंशधारकों से किया जायेगा ।</p>


                <p style="text-align:justify; font-size: 15px;line-height: 1.8 !important;"><strong>2- सामान्य सदस्य:</strong> रुपये 10,000 /- (रुपये 5000 /- सदस्यता शुल्क एवं रुपये 5000 /- वार्षिक शुल्क) जमा करने वाले को साधारण सदस्य बनाया जा सकता है, बशर्ते कि निर्देशक मंडल उसका अनुमोदन करें ।</p>

                <p style="text-align:justify; font-size: 15px;line-height: 1.8 !important;"><strong>३- उदीयमान / क्षमतावान उद्यमी:</strong> रुपये 500/- जमा करने वाले को उदीयमान / क्षमतावान उद्यमी सदस्य बनाया जा सकता है बशर्ते कि निर्देशक मंडल उसका अनुमोदन करे ।</p>


                <p style="text-align:justify; font-size: 15px;line-height: 1.8 !important;"><strong>४- एसोसिएट सदस्यता:</strong> किसी भी कॉरपोरेट / ग्रुप को निर्देशक मंडल के अनुमोदन से निर्धारित फीस के साथ एसोसिएट सदस्य बनाया जा सकता है ।</p>

            </div>
        </div>





    </div>

    <!-- -------------------------------------------- about section end ---------------------------------- -->





    <?php include('include/footer.php'); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4"
        crossorigin="anonymous"></script>
    <?php include('include/js.php'); ?>
</body>

</html>