<!doctype html>
<!--    style="line-height:2;"     -->
<html lang="en,hi">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content>
    <meta name="author" content="DynamicLayers">
    <title>Ngo/Charity|| Farmer becomes businessman</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

        <style type="text/css">
    
      
    input{
        width: 80%;
        padding: 5px;
        border-radius: 10px;
  
    }
  
 
    </style>
    <?php include('include/css.php'); ?>
</head>

<body>

    <?php include('include/header.php'); ?>

    <div class="header-height"></div>





<section>
<div class="container" style="padding-top:65px;">
    <div class="row">
        <div class="col-md-12">
            <h2 style="text-align:center;padding:20px;background-color:#288528; color:white; border-radius: 10px;">Sign Up Form</h2>
        </div>
    </div>
</div>
</section>


<section>
<div class="container" style="padding-top:55px; padding-bottom:55px;">


<div class="row" style="box-shadow:20px 20px 50px 10px #069f0ad1 inset; padding:40px;">
  
<div class="col-md-3"></div>


<div class="col-md-8">
<p style="margin-left:150px;"><strong>Quick Enquiry / Review / Suggestion</strong></p>

<div class="row">
<div class="col-md-6" style="">

<input type="text" name="name" placeholder="First Name *" style="margin-top:50px;">
<input type="mobileno" name="mobileno" placeholder="Email  *" style="margin-top:30px;">

    </div>
<div class="col-md-6" style="">

<input type="email" name="email" placeholder="Last Name *" style="margin-top:50px;">
<input type="mobileno" name="mobileno" placeholder="Mobile Number *" style="margin-top:30px;">

</div>

<input type="type" name="subject" placeholder="Address *" style="margin-top:50px; height:100px; width:86%!important;margin-left:15px;">

</div>
<input type="submit" value="Submit" style="margin-top:50px;padding:15px;width:20%;">




</div>


<div class="col-md-2"></div>
   
</div>


    </div>
</section>







    <?php include('include/footer.php'); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4"
        crossorigin="anonymous"></script>
    <?php include('include/js.php'); ?>
</body>

</html>