
<p ><img src="themes/footer_1.png" alt="" style="height:3rem!important;"></p>
<!-- <section style="background-image:url('themes/footer_1.png');"></section> -->
<section class="widget-section padding" style="margin-top:-1rem;">
<div class="container">
<div class="widget-wrap row">
<div class="col-md-4 xs-padding">
<div class="widget-content">
<img src="themes/footer-2.png" alt="logo" style="height:5rem;">
<p class="text" style="line-height: 1;color:white;padding:0.5rem;">The secret to happiness lies in helping others. Never underestimate the difference you can make in the lives of the poor.</p>

</div>
</div>
<div class="col-md-4 xs-padding">
<div class="widget-content">
<h3>Recent Campaigns</h3>
<ul class="widget-link">
<li><a href="#" style=" color:white;">First charity activity of this summer. <span>-1 Year Ago</span></a></li>
<li><a href="#" style="line-height: 1.5; color:white;">Big charity: build school for poor children. <span>-2 Year Ago</span></a></li>
<li><a href="#" style=" color:white;">Clean-water system for rural poor. <span>-2 Years Ago</span></a></li>
</ul>
</div>
</div>
<div class="col-md-4 xs-padding">
<div class="widget-content">
<h3>Charity  Location</h3>
<ul class="address">
<li style="color: white;"><i class="ti-email"></i> kbcciindia@gmail.com</i>
<li style="color: white;"><i class="ti-mobile"></i> (011)-40801129</li>
<li style="color: white;"><i class="ti-world"></i> Www.YourWebsite.com</li>
<li style="color: white;"><i class="ti-location-pin"></i> Chetan Plaza, LSC, Delhi – 110091, INDIA</li>
</ul>
</div>
</div>

</div>
</div>
<div class="container">
    <div class="row widget-content" style="text-align: center;">
   
<ul class="social-icon">
<li><a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a></li>
<li><a href="https://www.twitter.com/"><i class="fa fa-twitter"></i></a></li>
<li><a href="https://www.pinterest.com/"><i class="fa fa-pinterest"></i></a></li>
<li><a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a></li>
<li><a href="https://www.linkedin.com/"><i class="fa fa-linkedin"></i></a></li>
</ul>

    </div>
</div>

</section>




<section>
    <div class="containerr" >
        <div class="row">
            <div class="col-md-12" style="background-color:black;">
                <p style="padding-top:10px;text-align:center;color:white; font-size:14px;">&copy;  2023 KBCCI All Rights Reserved.</p>
            </div>
        </div>
    </div>
</section>
