
    
    <header id="header" class="header-section">
        <div class="top-header">
            <div class="container">
                <div class="top-content-wrap row">
                <div class="col-8 col-sm-6 col-md-8 col-lg-8">
                 <div class="row">
                    <div class="col-12 col-sm-12 col-md-12 col-lg-6">
                   <a href="index.php"> <img src="themes/logo-1.jpg" alt="logo of kbcci" title="kbcci logo" style="height:5rem;margin-left:-5rem;" ></a>

                    </div>
                    <div class="col-12 col-sm-12 col-md-12 col-lg-6" style="padding-left:2rem;">
                    <img src="themes/logo.jpg" alt="">

                    </div>
                 </div>  
                </div>
                    <div class="col-sm-4 d-none d-md-block" style="position: absolute; left: 63rem;">
                    <ul class="left-info">
                            <li style="font-size:2rem;"><a href="#"><i class="ti-email"></i>kicciindia@gmail.com</a>
                            </li>
                            <li style="font-size:2rem;"><a href="#"><i class="ti-mobile"></i>+(011)-40801129</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="bottom-header">
            <div class="container">
                <div class="bottom-content-wrap row">
                  
                    <div class="col-sm-10 text-right" style="">
                    <div class="site-branding">
                        </div>
                        <ul id="mainmenu" class="nav navbar-nav nav-menu">
                            <li class="active"> <a href="index.php">Home</a> </li>
                             
                           
                            <li><a href="about.php">About KBCCI</a></li>
                            <li><a href="javaScript:void(0);">Kisan</a></li>
                            <li><a href="javaScript:void(0);">Start Up</a></li>
                            <li><a href="javaScript:void(0);">Business</a></li>
                            <li><a href="b2b.php">B2B </a></li>
                            <li><a href="event_gallery.php"> Event Gallery</a></li>
                            <li><a href="team.php">Team</a></li>
                            <li> <a href="contact.php">Contact</a></li>
                            <li><a href="chapters.php">Chapters</a></li>
                    
                        </ul>
                      
                    </div>
                    <div class="col-sm-2 text-right">
                    <a href="sign_up.php" class="default-btn ">Sign Up</a>

                    </div>
                </div>
            </div>
        </div>
    </header>





<!-- Modal -->
<div class="modal fade" id="founder_member" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="founder_member">Modal title</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        

        <span> <img src="themes/image/founder-mem-1.jpg" id="setImg" style="height: 150px; width: 150px; border-radius: 20px; "></span> 
        <span id="setname" style="padding-left:60px;"></span> 
         <p id="setfounder" style="padding-top:30px;"></p>
         <p id="setcontent" style="padding-top:10px;"></p>





      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
       
      </div>
    </div>
  </div>
</div>










