<link rel="shortcut icon" type="image/x-icon" href="themes/logo/fabicon.jpg">

<link rel="stylesheet" href="themes/css/font-awesome.min.css">

<link rel="stylesheet" href="themes/css/themify-icons.css">

<link rel="stylesheet" href="themes/css/elegant-font-icons.css">

<link rel="stylesheet" href="themes/css/elegant-line-icons.css">

<link rel="stylesheet" href="themes/css/bootstrap.min.css">

<link rel="stylesheet" href="themes/css/venobox/venobox.css">

<link rel="stylesheet" href="themes/css/owl.carousel.css">

<link rel="stylesheet" href="themes/css/slicknav.min.css">

<link rel="stylesheet" href="themes/css/css-animation.min.css">

<link rel="stylesheet" href="themes/css/nivo-slider.css">

<link rel="stylesheet" href="themes/css/main.css">

<link rel="stylesheet" href="themes/css/responsive.css">

<link rel="stylesheet" href="themes/css/as_css.css">

<script src="themes/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>