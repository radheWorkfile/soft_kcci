<!doctype html>
<!--    style="line-height:2;"     -->

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content>
  <meta name="author" content="DynamicLayers">
  <title>Ngo/Charity|| Farmer becomes businessman</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
<style>

</style>
  <?php include('include/css.php'); ?>
  <style>
    .button:hover{
background-color: green;
color: green;
    }
    body{
      overflow-x: hidden;
    }
    .rad{
      border-radius:1rem;
    }
  </style>
</head>

<body>

  <?php include('include/header.php'); ?>

  <div class="header-height"></div>


  <section class="slider-section" style="width:75%;padding:2rem;">
    <div class="slider-wrapper">
      <div id="main-slider" class="nivoSlider"style="height:420px;">
        <img src="themes/img/banner-check.jpg" alt title="#slider-caption-1">
        <img src="themes/img/banner_image_2.jpg" alt title="#slider-caption-2">
        <img src="themes/img/slider-3.jpg" alt title="#slider-caption-3">
      </div>
      <div id="slider-caption-1" class="nivo-html-caption slider-caption">
        <div class="display-table">
          <div class="table-cell">
            <div class="container">
              <div class="slider-text">
                <h5 class="wow cssanimation fadeInBottom">Join Us Today</h5>
                <h1 class="wow cssanimation leFadeInRight sequence">Farmer becomes businessman</h1>
                <p class="wow cssanimation fadeInTop" data-wow-delay="1s" style="line-height:2;">
                <strong>Help today because
                  tomorrow you may be the one who needs helping! <br>Forget what you can get and see what you can give.</strong>
                </p>
                <a href="sign_up.php" class="default-btn wow cssanimation fadeInBottom" data-wow-delay="0.8s">Join With Us</a>
                <a href="contact.php" class="default-btn wow cssanimation fadeInBottom" data-wow-delay="0.8s">Contact Us</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="slider-caption-2" class="nivo-html-caption slider-caption">
        <div class="display-table">
          <div class="table-cell">
            <div class="container">
              <div class="slider-text">
                <h1 class="wow cssanimation fadeInTop" data-wow-delay="1s" data-wow-duration="800ms" style="color:white;">Farmer becomes
                  businessman</h1>
                <p class="wow cssanimation fadeInBottom" data-wow-delay="1s" style="line-height:2; color:white;">Help today because
                  tomorrow you may be the one who needs helping! <br>Forget what you can get and see what you can give.
                </p>
                <a href="#" class="default-btn wow cssanimation fadeInBottom" data-wow-delay="0.8s">Join With Us</a>
                <a href="#" class="default-btn wow cssanimation fadeInBottom" data-wow-delay="0.8s">Donet Now</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="slider-caption-3" class="nivo-html-caption slider-caption">
        <div class="display-table">
          <div class="table-cell">
            <div class="container">
              <div class="slider-text">
                <h5 class="wow cssanimation fadeInBottom" style="color:white;">Join Us Today</h5>
                <h1 class="wow cssanimation lePushReleaseFrom sequence" data-wow-delay="1s" style="line-height:2; color:white;">
                  Farmer becomes businessman</h1>
                <p class="wow cssanimation fadeInTop" data-wow-delay="1s" style="color:white;">Help today because tomorrow you may be the one
                  who needs helping! <br>Forget what you can get and see what you can give.</p>
                <a href="#" class="default-btn wow cssanimation fadeInBottom" data-wow-delay="0.8s">Join With Us</a>
                <a href="#" class="default-btn wow cssanimation fadeInBottom" data-wow-delay="0.8s">Donet Now</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  </section>

  <section style="margin-left:63rem;margin-top:-28.2rem; padding-left:0.5rem;padding-top:1rem;margin-right:1.5rem;;box-shadow: 1px 1px 5px 3px grey;">
  <div class="" >
  <div class="section-heading mb-50" style="">
        <h2 style="padding:1.5rem;font-size:2rem;">Founder Members</h2>
        <img src="themes/image/founder-mem-1.jpg" alt="" style="margin-left:3rem;border-radius:50%;">
        <p style="margin-left:5.5rem;margin-top:1rem;">Mr.Bhanu_Prasad</p>
        <button class="btn button radheActn" id="1" data-bs-toggle="modal" data-bs-target="#founder_member"  style="margin-left:86px;margin-bottom:0.8rem; background-color:rgba(142, 224, 167, 0.6);">View Details</button>
  </div>
  </div>
    
  </section>



  <section class="text rotate" style="margin-top:-1.2rem;">
    <div class="containerr">
      <div class="row" marque_text>
        <div class="col-md-12" style="width: 100%; height: 30px; background-color: #009000; ">
          <marquee behavior="" direction="left">
            <p style="padding-top:8px; color:white;"><b> Farmer becomes businessman &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;
                &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;
                &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Regular meetings are held at KBCCI corporate office every
                saturday between 5:00 PM - 6:30 PM &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                Farmer becomes businessman KBCCI Shareholders meeting will be held at KBCCI Corp.
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Office on 18th Aug 2023</b></p>
          </marquee>
        </div>
      </div>
    </div>
  </section>







  <section class="promo-section ">
    <div class="promo-wrap">
      <div class="container">
        <div class="row">
          <div class="col-md-4 col-sm-6">
            <div class="promo-content">
              <img src="themes/img/icon-1.png" alt="prmo icon">
              <h3>Farmer</h3>
              <p style="line-height: 1;">A farmer is a person who runs and works on a farm.</p>
              <a href="#">Read More</a>
            </div>
          </div>
          <div class="col-md-4 col-sm-6">
            <div class="promo-content">
              <img src="themes/img/icon-2.png" alt="prmo icon">
              <h3>Startup </h3>
              <p style="line-height: 1;">The term startup refers to a company in the first stages of operations.</p>
              <a href="#">Read More</a>
            </div>
          </div>
          <div class="col-md-4 col-sm-6 xs-padding">
            <div class="promo-content">
              <img src="themes/img/icon-3.png" alt="prmo icon">
              <h3>Business</h3>
              <p style="line-height: 1;">he purpose of a business is to organize some sort of economic production of goods or services.</p>
              <a href="#">Read More</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="testimonial-section bd-bottom padding" style="padding-top:150px;">
    <div class="container">
      <div class="section-heading text-center mb-40">
        <h2>Founder Members</h2>
        <span class="heading-border"></span>
        <!-- <p>Help today because tomorrow you may be the one who <br> needs more helping!</p> -->
      </div>
      <div id="testimonial-carousel" class="testimonial-carousel owl-carousel">
        <div class="testimonial-item">
          <div class="testi-foote">
            <img id="img_1" src="themes/image/founder-mem-1.jpg" alt="profile" style="border-radius: 50%; height:200px; width:200px; padding:10px; margin-left:50px;">
            <h4 style="margin-left:100px;" style="margin-left:20px;" id="name_1">Mr. Bhanu  <span>Prasad </span></h4>
            <button class="btn button radheActn" id="1" data-bs-toggle="modal" data-bs-target="#founder_member"  style="margin-left:100px; background-color:rgba(142, 224, 167, 0.6);">View Details</button>
          </div>
        </div>
        <div  class="testimonial-item">
          <div class="testi-foote">
            <img id="img_2" src="themes/image/founder-mem-3.jpg" alt="profile" style="border-radius: 50%; height:200px; width:200px; padding:10px; margin-left:50px;">
            <h4 style="margin-left:75px;" id="name_2">Mr. Harish Chandra  <span>Roy</span></h4>
            <button type="button" class="btn button radheActn" id="2" data-bs-toggle="modal" data-bs-target="#founder_member" style="margin-left:100px; background-color:rgba(142, 224, 167, 0.6);">View Details</button>

          </div>
        </div>
        <div  class="testimonial-item">
          <div class="testi-foote">
            <img id="img_3" src="themes/image/founder-mem-4.jpg" alt="profile" style="border-radius: 50%; height:200px; width:200px; padding:10px; margin-left:50px;">
            <h4 style="margin-left:95px;" id="name_3">Mr. Ashok  <span>Mehta</span></h4>
            <button class="btn button radheActn" id="3" data-bs-toggle="modal" data-bs-target="#founder_member" style="margin-left:100px; background-color:rgba(142, 224, 167, 0.6);">View Details</button>

          </div>
        </div>
        <div  class="testimonial-item">
          <div class="testi-foote">
            <img  id="img_4" src="themes/image/founder-mem-5.jpg" alt="profile" style="border-radius: 50%; height:200px; width:200px; padding:10px; margin-left:50px;">
            <h4 style="margin-left:80px;" id="name_4">Mr. Sunil Kumar <span>Singh</span></h4>
            <button class="btn button radheActn" id="4" data-bs-toggle="modal" data-bs-target="#founder_member" style="margin-left:100px; background-color:rgba(142, 224, 167, 0.6);">View Details</button>

          </div>
        </div>

        <div  class="testimonial-item">
          <div class="testi-foote">
            <img id="img_5" src="themes/image/founder-mem-6.jpg" alt="profile" style="border-radius: 50%; height:200px; width:200px; padding:10px; margin-left:50px;">
            <h4 style="margin-left:95px;  " id="name_5">Mr. Anil  <span>Kumar</span></h4>
            <button class="btn button radheActn" id="5" data-bs-toggle="modal" data-bs-target="#founder_member" style="margin-left:100px; background-color:rgba(142, 224, 167, 0.6);">View Details</button>

          </div>
        </div>

        <div  class="testimonial-item">
          <div class="testi-foote">
            <img id="img_6" src="themes/image/founder-mem-7.jpg" alt="profile" style="border-radius: 50%; height:200px; width:200px; padding:10px; margin-left:50px;">
            <h4 style="margin-left:73px;" id="name_6">Mr. Piyush Kumar <span>Singh</span></h4>
            <button class="btn button radheActn" id="6" data-bs-toggle="modal" data-bs-target="#founder_member" style="margin-left:100px; background-color:rgba(142, 224, 167, 0.6);">View Details</button>

          </div>
        </div>

        <div  class="testimonial-item">
          <div class="testi-foote">
            <img id="img_7" src="themes/image/founder-mem-8.jpg" alt="profile" style="border-radius: 50%; height:200px; width:200px; padding:10px; margin-left:50px;">
            <h4 style="margin-left:75px;" id="name_7">Mr. Dharmendra  <span>Singh</span></h4>
            <button class="btn button radheActn" id="7" data-bs-toggle="modal" data-bs-target="#founder_member" style="margin-left:100px; background-color:rgba(142, 224, 167, 0.6);">View Details</button>

          </div>
        </div>

        <div  class="testimonial-item">
          <div class="testi-foote">
            <img id="img_8" src="themes/image/founder-mem-9.jpg" alt="profile" style="border-radius: 50%; height:200px; width:200px; padding:10px; margin-left:50px;">
            <h4 style="margin-left:65px;" id="name_8">Mr. Umesh Chandra <span>Gangwa</span></h4>
            <button class="btn button radheActn" id="8" data-bs-toggle="modal" data-bs-target="#founder_member" style="margin-left:100px; background-color:rgba(142, 224, 167, 0.6);">View Details</button>

          </div>
        </div>

        <div class="testimonial-item">
          <div class="testi-foote">
            <img id="img_9" src="themes/image/founder-mem-10.jpg" alt="profile" style="border-radius: 50%; height:200px; width:200px; padding:10px; margin-left:50px;">
            <h4 style="margin-left:100px;" id="name_9"> Mr.Gyan  <span>Singh</span></h4>
            <button class="btn button radheActn" id="9" data-bs-toggle="modal" data-bs-target="#founder_member" style="margin-left:100px; background-color:rgba(142, 224, 167, 0.6);">View Details</button>

          </div>
        </div>

        <div  class="testimonial-item">
          <div class="testi-foote">
            <img id="img_10" src="themes/image/founder-mem-11.jpg" alt="profile" style="border-radius: 50%; height:200px; width:200px; padding:10px; margin-left:50px;">
            <h4 style="margin-left:80px;" id="name_10">Mr. Anil Kumar  <span>Gangwar</span></h4>
            <button class="btn button radheActn" id="10" data-bs-toggle="modal" data-bs-target="#founder_member" style="margin-left:100px; background-color:rgba(142, 224, 167, 0.6);">View Details</button>

          </div>
        </div>

        <div class="testimonial-item">
          <div class="testi-foote">
            <img id="img_11" src="themes/image/founder-mem-12.jpg" alt="profile" style="border-radius: 50%; height:200px; width:200px; padding:10px; margin-left:50px;">
            <h4 style="margin-left:80px;" id="name_11">Mr. Priyadarshi  <span>Ashok</span></h4>
            <button class="btn button radheActn" id="11" data-bs-toggle="modal" data-bs-target="#founder_member" style="margin-left:100px; background-color:rgba(142, 224, 167, 0.6);">View Details</button>

          </div>
        </div>

        <div  class="testimonial-item">
          <div class="testi-foote">
            <img id="img_12" src="themes/image/founder-mem-13.jpg" alt="profile" style="border-radius: 50%; height:200px; width:200px; padding:10px; margin-left:50px;">
            <h4 style="margin-left:75px;" id="name_12">Mr. Arun Kumar  <span>Sachan</span></h4>
            <button class="btn button radheActn" id="12" data-bs-toggle="modal" data-bs-target="#founder_member" style="margin-left:100px; background-color:rgba(142, 224, 167, 0.6);">View Details</button>

          </div>
        </div>
      </div>
    </div>
  </section>


  <section>
    <div class="container main_option" style="padding-bottom:75px;">
      <div class="row">


        <div class="col-lg-4 sm-padding">
          <div class="" style="height: 350PX; width: 100%; background-color: rgba(142, 224, 167, 0.4); ">
            <h3 style="background-color: green; padding: 10px; text-align: center; color:white;">FARMERS / कृषक मंच</h2>
              <div class="text" style="max-height: 85%; width: 75%; margin: auto;  ">

                <li style="padding:5px;">कृषक मंच Farmer's Forum</li>
                <li style="padding:5px;">जैविक खेती</li>
                <li style="padding:5px;">मशरूम खेती</li>
                <li style="padding:5px;">अदरक की उन्नत खेती</li>
                <li style="padding:5px;">कटहल की खेती</li>
                <li style="padding:5px;">केले की खेती</li>
                <li style="padding:5px;">धनिया की उन्नत फ़सल</li>
                <p style="text-align:center; padding-top:30px; color:#fc500b; ">Many pages inside, click any link.</p>

              </div>
          </div>
        </div>


        <div class="col-lg-4 sm-padding">
          <div class="" style="height: 350PX; width:100%; background-color: rgba(142, 224, 167, 0.4); ">
            <h3 style="background-color: green; padding: 10px; text-align: center; color:white;">BUSINESS WORLD</h2>
              <div class="text" style="max-height: 85%; width: 75%; margin: auto;  ">

                <li style="padding:5px;">B2B: An Introduction.</li>
                <li style="padding:5px;">Best Practices in Kommunity.</li>
                <li style="padding:5px;">Romano's Pizza.</li>
                <li style="padding:5px;">LED Bulb: Gram Jyoti</li>
                <li style="padding:5px;">Sameer Appliances</li>
                <li style="padding:5px;">TILA:Legal Services</li>
                <li style="padding:5px;">Nicholas Shoes</li>
                <p style="text-align:center; padding-top:30px; color:#fc500b; ">Many pages inside, click any link.</p>



              </div>
          </div>
        </div>


        <div class="col-lg-4 sm-padding">
          <div class="" style="height: 350PX; width: 100%; background-color: rgba(142, 224, 167, 0.4); ">
            <h3 style="background-color: green; padding: 10px; text-align: center; color:white;">GEN-NEXT / YOUTH</h2>
              <div class="text" style="max-height: 85%; width: 75%; margin: auto;  ">

                <li style="padding:5px;">Home</li>
                <li style="padding:5px;">Business Ideas Part 01</li>
                <li style="padding:5px;">Business Ideas Part 02</li>
                <li style="padding:5px;"> How to Start a Small Business </li>
                <li style="padding:5px;">Items for Small Scale Industries</li>
                <li style="padding:5px;">Property Consultant</li>
                <!-- <li style="padding:5px;"></li> -->
                <p style="text-align:center; padding-top:55px; color:#fc500b; ">Many pages inside, click any link.</p>

              </div>
          </div>
        </div>



      </div>
    </div>
  </section>









  <section class="team-section bg-grey bd-bottom circle shape padding">
    <div class="container">
      <div class="section-heading text-center mb-40">
        <h2>Upcomeing Event</h2>
        <span class="heading-border"></span>
        <p>Help today because tomorrow you may be the one who <br> needs more helping!</p>
      </div>
      <div class="team-wrapper row">
        <div class="col-md-1"></div>
   
        <div class="col-6 sm-12 md-4 lg-4" >
          <div class="" style="height: 300px; width: 400px; background-color: rgba(142, 224, 167, 0.4); ">
            <h3 style="background-color: green; padding: 2px; text-align: center; color:white;">Events</h2>







            <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
    <div class="text" style="height: 75%; width: 65%; margin: auto; padding-top:30px; text-align: justify;">
                      <strong>

                        <ul id="nt-example1">
                          <strong>
                            <li style="border: 1px solid green; padding:20px; border-radius:20px;">
                              <div class="curr_eve">
                                <p><i class="fa fa-calendar" aria-hidden="true"></i><a class="date_eve">2022-03-02</a><a href="#" class="pull-right"></a></p>
                                <p></p>
                                <p>Monthly meeting will be held on date&nbsp;<strong>2nd march 20222&nbsp;</strong>in KICCI office timing of meeting notified very soon.&nbsp;&nbsp;<!--...<a href='upcoming.php?id=3' class='btn btn-success more_b'-->More Details</p>
                              </div>
                            </li>
                          </strong>
                      </strong>
                    </div>
      <!-- <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTxhtmBqlJilp6X2q2XsYxJ9DVYb_F8x17DjIOJcHtT&s" class="d-block w-100" alt="..."> -->
    </div>
    <div class="carousel-item">
    <div class="text" style="height: 75%; width: 65%; margin: auto; padding-top:30px; text-align: justify;">
                      <strong>

                        <ul id="nt-example1">
                          <strong>
                            <li style="border: 1px solid green; padding:20px; border-radius:20px;">
                              <div class="curr_eve">
                                <p><i class="fa fa-calendar" aria-hidden="true"></i><a class="date_eve">2022-03-02</a><a href="#" class="pull-right"></a></p>
                                <p></p>
                                <p>Monthly meeting will be held on date&nbsp;<strong>2nd march 20222&nbsp;</strong>in KICCI office timing of meeting notified very soon.&nbsp;&nbsp;<!--...<a href='upcoming.php?id=3' class='btn btn-success more_b'-->More Details</p>
                              </div>
                            </li>
                          </strong>
                      </strong>
                    </div>
      <!-- <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTxhtmBqlJilp6X2q2XsYxJ9DVYb_F8x17DjIOJcHtT&s" class="d-block w-100" alt="..."> -->
    </div>
    <div class="carousel-item">
    <div class="text" style="height: 75%; width: 65%; margin: auto; padding-top:30px; text-align: justify;">
                      <strong>

                        <ul id="nt-example1">
                          <strong>
                            <li style="border: 1px solid green; padding:20px; border-radius:20px;">
                              <div class="curr_eve">
                                <p><i class="fa fa-calendar" aria-hidden="true"></i><a class="date_eve">2022-03-02</a><a href="#" class="pull-right"></a></p>
                                <p></p>
                                <p>Monthly meeting will be held on date&nbsp;<strong>2nd march 20222&nbsp;</strong>in KICCI office timing of meeting notified very soon.&nbsp;&nbsp;<!--...<a href='upcoming.php?id=3' class='btn btn-success more_b'-->More Details</p>
                              </div>
                            </li>
                          </strong>
                      </strong>
                    </div>
      <!-- <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTxhtmBqlJilp6X2q2XsYxJ9DVYb_F8x17DjIOJcHtT&s" class="d-block w-100" alt="..."> -->
    </div>
  </div>

</div>


</div>
        </div>






        <div class="col-lg-4 sm-padding" >
          <div class="" style="height: 300px; width: 400px; background-color: rgba(142, 224, 167, 0.4); ">
            <h3 style="background-color: green; padding: 2px; text-align: center; color:white;">REVIEWS</h2>
              <div class="text" style="max-height: 75%; width: 65%; margin: auto;  ">

                <marquee behavior="" direction="up" style="height:175px;">
                  <p style="text-align: justify; line-height:2;">
                    " KBCCI (Kommunity Bihar Chamber of Commerce and Industry) has taken an innovative step to transform
                    social capital in to financial capital. Definitely, it will go a long way. Our farmers really need a
                    guide-cum-motivator to deliver their best. "
                    <br><br>
                  <p style="text-align:center; padding:10px;">Siya Ram Sachan,
                    Greater Noida</p>
                  <hr style="padding-top:20px;">
                  " This organization will do wonders in the life of agrarian community. Our farmers require forward
                  linkage for better value of their outputs. KICCI will be a torch-bearer in this direction. I an
                  looking forward with it's philosophy. "
                  <br><br>
                  <hr style="">
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Pramod
                  Sachan, Mumbai
                  </p>

                </marquee>

              </div>

              <p style="text-align:center; background-color:#009000; padding:10px; color:white; width:100px; margin:auto;"><a href="" style="color:white;">More View</a></p>


          </div>
        </div>
      </div>
    </div>
  </section>



  <section id="counter" class="counter-section" style="margin-top:50px;" >
    <div class="container">
      <ul class="row counters">
        <li class="col-md-3 col-sm-6 sm-padding">
          <div class="counter-content">
            <!-- <i class="ti-money"></i> -->
            <!-- <h3 class="counter">85389</h3> -->
            <!-- <h4 style="margin-left:20px;" class="text-white">Money Donated</h4> -->
          </div>
        </li>
        <li class="col-md-3 col-sm-6 sm-padding">
          <div class="counter-content">
            <i class="ti-face-smile" style="color: white;"></i>
            <h3 class="counter" style="color: white;">10693</h3>
            <h2 class="text-green" style="color: #800000;"> Farmer</h4>
          </div>
        </li>
        <li class="col-md-3 col-sm-6 sm-padding">
          <div class="counter-content">
            <i class="ti-user" style="color: white;"></i>
            <h3 class="counter" style="color: white;">50177</h3>
            <h2 class="text-green" style="color: #800000;">Startup </h4>
          </div>
        </li>
        <li class="col-md-3 col-sm-6 sm-padding">
          <div class="counter-content">
            <i class="ti-comments" style="color: white;"></i>
            <h3 class="counter" style="color: white;">669</h3>
            <h2 class="text-green" style="color: #800000;">Business </h4>
          </div>
        </li>
      </ul>
    </div>
  </section>




  <section>
    <div class="containerr" style=" margin-top:40px;">
      <div class="section-heading text-center mb-40">
        <h2>Gallery </h2>
        <span class="heading-border"></span>
      </div>
      <div class="row"style="margin-bottom:5px; margin-top:66px;">
        <div class="col-lg-12 sm-padding" style="padding:yop:55px;">
          <div class="team-wrap row">
            <div class="col-md-3" style="position: relative;" >
              <div class="team-details">
                <div class="" style="background-color:green;">
                  <img src="themes/img/team-4.jpg" alt="team" class="team_image">
                  
                </div>
              </div>
            </div>
            <div class="col-md-3">
              <div class="team-details">
                <div class="" style="background-color:green;">
                  <img src="themes/img/team-2.jpg" alt="team" class="team_image">

                </div>

              </div>
            </div>
            <div class="col-md-3">
              <div class="team-details">
                <div class="" style="background-color:green;">
                  <img src="themes/img/team-1.jpg" alt="team" class="team_image">

                </div>

              </div>
            </div>
            <div class="col-md-3">
              <div class="team-details">
                <div class="" style="background-color:green;">
                  <img src="themes/img/team-3.jpg" alt="team" class="team_image">

                </div>

              </div>
            </div>
            





          </div>
        </div>
        




      </div>
      </div>

   
  </section>

  <!-- <p><a href="event_gallery.php" style="color:white;">View More</a></p> -->
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <p style="padding:20px;"></p>
    
    </div>
  </div>
</div>












  
  <?php include('include/footer.php'); ?>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
  <?php include('include/js.php'); ?>
</body>

</html>