<!doctype html>
<!--    style="line-height:2;"     -->
<html lang="en,hi">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content>
    <meta name="author" content="DynamicLayers">
    <title>Ngo/Charity|| Farmer becomes businessman</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

        <style type="text/css">
        @font-face {
            font-family: kruti dev;
            src: url("fonts/Kruti_Dev_010.ttf"), url("fonts/Kruti_Dev_010.eot");
        }
    </style>
    <?php include('include/css.php'); ?>
</head>

<body>

    <?php include('include/header.php'); ?>

    <div class="header-height"></div>


    <section class="slider-section">
        <div class="slider-wrapper">
            <div id="main-slider" class="nivoSlider" style="height:300px;">
                <img src="themes/img/about-image-1.jpg" alt title="#slider-caption-1" />
           
            </div>
            <div id="slider-caption-1" class="nivo-html-caption slider-caption">
                <div class="display-table">
                    <div class="table-cell">
                        <div class="container">
                            <div class="slider-text">
                                <h5 class="wow cssanimation fadeInBottom">Join Us Today</h5>
                                <h1 class="wow cssanimation leFadeInRight sequence">Team Member</h1>
                                <p class="wow cssanimation fadeInTop" data-wow-delay="1s" style="line-height:2; color:white;">Help
                                    today because
                                    tomorrow you may be the one who needs helping! <br>Forget what you can get and see
                                    what you can give.
                                </p>
                                <a href="index.php" class="default-btn wow cssanimation fadeInBottom" data-wow-delay="0.8s">Home</a>
                                <a href="javaScript:void(0);" class="default-btn wow cssanimation fadeInBottom"
                                    data-wow-delay="0.8s">Team</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="slider-caption-2" class="nivo-html-caption slider-caption">
                <div class="display-table">
                    <div class="table-cell">
                        <div class="container">
                            <div class="slider-text">
                                <h1 class="wow cssanimation fadeInTop" data-wow-delay="1s" data-wow-duration="800ms">
                                    Farmer becomes
                                    bussinessman</h1>
                                <p class="wow cssanimation fadeInBottom" data-wow-delay="1s" style="line-height:2;">Help
                                    today because
                                    tomorrow you may be the one who needs helping! <br>Forget what you can get and see
                                    what you can give.
                                </p>
                                <a href="#" class="default-btn wow cssanimation fadeInBottom" data-wow-delay="0.8s">Join
                                    With Us</a>
                                <a href="#" class="default-btn wow cssanimation fadeInBottom"
                                    data-wow-delay="0.8s">Donet Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="slider-caption-3" class="nivo-html-caption slider-caption">
                <div class="display-table">
                    <div class="table-cell">
                        <div class="container">
                            <div class="slider-text">
                                <h5 class="wow cssanimation fadeInBottom">Join Us Today</h5>
                                <h1 class="wow cssanimation lePushReleaseFrom sequence" data-wow-delay="1s"
                                    style="line-height:2;">
                                    Farmer becomes bussinessman</h1>
                                <p class="wow cssanimation fadeInTop" data-wow-delay="1s">Help today because tomorrow
                                    you may be the one
                                    who needs helping! <br>Forget what you can get and see what you can give.</p>
                                <a href="#" class="default-btn wow cssanimation fadeInBottom" data-wow-delay="0.8s">Join
                                    With Us</a>
                                <a href="#" class="default-btn wow cssanimation fadeInBottom"
                                    data-wow-delay="0.8s">Donet Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


<section>
<div class="container" style="padding-top:65px;">
    <div class="row">
        <div class="col-md-12">
            <h2 style="text-align:center;padding:20px;background-color:#288528; color:white; border-radius: 10px;">Oue Team</h2>
        </div>
    </div>
</div>
</section>



<section>
<div class="container">
<div class="row" >
<div class="col-md-3">
    
<div  class="testimonial-item">
          <div class="testi-foote">
            <img id="img_8" src="themes/image/founder-mem-9.jpg" alt="profile" style="border-radius: 15%; height:200px; width:200px; padding:10px; margin-left:50px;">
            <h4 style="margin-left:65px;" id="name_8">Mr. Umesh Chandra <span>Gangwa</span></h4>
            <button class="btn button radheActn" id="8" data-bs-toggle="modal" data-bs-target="#founder_member" style="margin-left:100px; background-color:rgba(142, 224, 167, 0.6);">View Details</button>

          </div>
        </div>
</div>

<div class="col-md-3">
<div class="testimonial-item">
          <div class="testi-foote">
            <img id="img_1" src="themes/image/founder-mem-1.jpg" alt="profile" style="border-radius: 15%; height:200px; width:200px; padding:10px; margin-left:50px;">
            <h4 style="margin-left:100px;" style="margin-left:20px;" id="name_1">Mr. Bhanu  <span>Prasad </span></h4>
            <button class="btn button radheActn" id="1" data-bs-toggle="modal" data-bs-target="#founder_member"  style="margin-left:100px; background-color:rgba(142, 224, 167, 0.6);">View Details</button>
          </div>
        </div>
</div>

<div class="col-md-3">
<div  class="testimonial-item">
          <div class="testi-foote">
            <img id="img_2" src="themes/image/founder-mem-3.jpg" alt="profile" style="border-radius: 15%; height:200px; width:200px; padding:10px; margin-left:50px;">
            <h4 style="margin-left:75px;" id="name_2">Mr. Harish Chandra  <span>Roy</span></h4>
            <button type="button" class="btn button radheActn" id="2" data-bs-toggle="modal" data-bs-target="#founder_member" style="margin-left:100px; background-color:rgba(142, 224, 167, 0.6);">View Details</button>

          </div>
        </div>
</div>

<div class="col-md-3">
<div  class="testimonial-item">
          <div class="testi-foote">
            <img id="img_3" src="themes/image/founder-mem-4.jpg" alt="profile" style="border-radius: 15%; height:200px; width:200px; padding:10px; margin-left:50px;">
            <h4 style="margin-left:95px;" id="name_3">Mr. Ashok  <span>Mehta</span></h4>
            <button class="btn button radheActn" id="3" data-bs-toggle="modal" data-bs-target="#founder_member" style="margin-left:100px; background-color:rgba(142, 224, 167, 0.6);">View Details</button>

          </div>
        </div>
</div>

</div>




<div class="row">
    <div class="col-md-3">
    <div class="testi-foote">
            <img  id="img_4" src="themes/image/founder-mem-5.jpg" alt="profile" style="border-radius: 15%; height:200px; width:200px; padding:10px; margin-left:66px;">
            <h4 style="margin-left:80px;" id="name_4">Mr. Sunil Kumar <span>Singh</span></h4>
            <button class="btn button radheActn" id="4" data-bs-toggle="modal" data-bs-target="#founder_member" style="margin-left:100px; background-color:rgba(142, 224, 167, 0.6);">View Details</button>

          </div>
    </div>

    <div class="col-md-3">

    <div  class="testimonial-item">
          <div class="testi-foote">
            <img id="img_5" src="themes/image/founder-mem-6.jpg" alt="profile" style="border-radius: 15%; height:200px; width:200px; padding:10px; margin-left:50px;">
            <h4 style="margin-left:95px;  " id="name_5">Mr. Anil  <span>Kumar</span></h4>
            <button class="btn button radheActn" id="5" data-bs-toggle="modal" data-bs-target="#founder_member" style="margin-left:100px; background-color:rgba(142, 224, 167, 0.6);">View Details</button>

          </div>
        </div>
    </div>

    <div class="col-md-3">
    <div  class="testimonial-item">
          <div class="testi-foote">
            <img id="img_6" src="themes/image/founder-mem-7.jpg" alt="profile" style="border-radius: 15%; height:200px; width:200px; padding:10px; margin-left:50px;">
            <h4 style="margin-left:73px;" id="name_6">Mr. Piyush Kumar <span>Singh</span></h4>
            <button class="btn button radheActn" id="6" data-bs-toggle="modal" data-bs-target="#founder_member" style="margin-left:100px; background-color:rgba(142, 224, 167, 0.6);">View Details</button>

          </div>
        </div>
    </div>
    <div class="col-md-3">
    <div  class="testimonial-item">
          <div class="testi-foote">
            <img id="img_12" src="themes/image/founder-mem-13.jpg" alt="profile" style="border-radius: 15%; height:200px; width:200px; padding:10px; margin-left:50px;">
            <h4 style="margin-left:75px;" id="name_12">Mr. Arun Kumar  <span>Sachan</span></h4>
            <button class="btn button radheActn" id="12" data-bs-toggle="modal" data-bs-target="#founder_member" style="margin-left:100px; background-color:rgba(142, 224, 167, 0.6);">View Details</button>

          </div>
        </div>
    </div>

 
</div>


<div class="row">
    <div class="col-md-3">
        
    <div class="testimonial-item">
          <div class="testi-foote">
            <img id="img_11" src="themes/image/founder-mem-12.jpg" alt="profile" style="border-radius: 15%; height:200px; width:200px; padding:10px; margin-left:50px;">
            <h4 style="margin-left:80px;" id="name_11">Mr. Priyadarshi  <span>Ashok</span></h4>
            <button class="btn button radheActn" id="11" data-bs-toggle="modal" data-bs-target="#founder_member" style="margin-left:100px; background-color:rgba(142, 224, 167, 0.6);">View Details</button>

          </div>
        </div>
    </div>

    <div class="col-md-3">
    <div  class="testimonial-item">
          <div class="testi-foote">
            <img id="img_10" src="themes/image/founder-mem-11.jpg" alt="profile" style="border-radius: 15%; height:200px; width:200px; padding:10px; margin-left:50px;">
            <h4 style="margin-left:80px;" id="name_10">Mr. Anil Kumar  <span>Gangwar</span></h4>
            <button class="btn button radheActn" id="10" data-bs-toggle="modal" data-bs-target="#founder_member" style="margin-left:100px; background-color:rgba(142, 224, 167, 0.6);">View Details</button>

          </div>
        </div>
    </div>
    <div class="col-md-3">
    <div class="testimonial-item">
          <div class="testi-foote">
            <img id="img_9" src="themes/image/founder-mem-10.jpg" alt="profile" style="border-radius: 15%; height:200px; width:200px; padding:10px; margin-left:50px;">
            <h4 style="margin-left:100px;" id="name_9"> Mr.Gyan  <span>Singh</span></h4>
            <button class="btn button radheActn" id="9" data-bs-toggle="modal" data-bs-target="#founder_member" style="margin-left:100px; background-color:rgba(142, 224, 167, 0.6);">View Details</button>

          </div>
        </div>
    </div>
</div>
</div>



</section>









    <?php include('include/footer.php'); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4"
        crossorigin="anonymous"></script>
    <?php include('include/js.php'); ?>
</body>

</html>